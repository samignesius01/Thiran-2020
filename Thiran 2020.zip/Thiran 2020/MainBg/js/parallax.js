var scene = document.getElementById('parallax1');
var parallax = new Parallax(scene);